
package net.cccstudio.renewedthis.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class PurebedrockproductItem extends Item {
	public PurebedrockproductItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.UNCOMMON));
	}
}
