
package net.mcreator.renewedthis.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class EndermanlifeessenceItem extends Item {
	public EndermanlifeessenceItem() {
		super(new Item.Properties().stacksTo(64).fireResistant().rarity(Rarity.COMMON));
	}
}
