package net.mcreator.orepack.procedures;

public class TitaniumarmortickProcedure {
	public static void execute() {
	}
}
